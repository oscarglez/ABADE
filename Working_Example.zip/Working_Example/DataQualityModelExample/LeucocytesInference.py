# Crweate a class for training
from com_caixa_commons.src.utils import Config
from com_caixa_commons.src.utils import CommonsLog

import pandas as pd

class ModelLeucocytesInference(CommonsLog.CommonsLog):    
       
 def __init__(self,**modelVariables):
    super().__init__(__name__)
    pass
        
        
 def predict(self,*args,**kwargs):
    df = kwargs['data']
    self.debug(f'Prediction with data: {df.head(2)}')  
    df['tumor_class'] = 'non_evaluated'
    self.debug(f'After with data: {df.head(2)}')
    return df    