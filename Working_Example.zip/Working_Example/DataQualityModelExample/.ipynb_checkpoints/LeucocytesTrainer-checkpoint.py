# Crweate a class for training
from com_caixa_commons.src.utils import Config
from com_caixa_commons.src.utils import CommonsLog

import pandas as pd

class ModelTrainerLeucocytes(CommonsLog.CommonsLog):    
 TRAIN_SIZE = 0.70
 VAL_SIZE = 0.15   
 TEST_SIZE = 0.15
    
    
 def __init__(self,**modelVariables):
    super().__init__(__name__)
    pass
        
        
 def trainForModel(self,*args,**kwargs):
    df = kwargs['data']
    self.debug(f'Training with data')   
    self.debug(df.head(2))
    return df
    

 def trainPrecission(self,*args,**kwargs):
    print(*args)
    self.debug(f'PRECISSION MODEL --> {kwargs["modelname"]}')
    return 95

 

 def trainValidation(self,validationResult,*args,**kwargs):
    self.debug(validationResult)
    print(*args)

    
    self.debug(f'VALIDATION MODEL --> {kwargs["modelname"]} with result: {validationResult}')
    evaluated = False
    if validationResult > 90: 
        evaluated = True
    return evaluated