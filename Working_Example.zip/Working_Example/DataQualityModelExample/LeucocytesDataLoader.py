# Crweate a class for training
from com_caixa_commons.src.utils import Config
from com_caixa_commons.src.utils import CommonsLog
from com_caixa_commons.src.utils import CommonsTest 


import pandas as pd

class DataLoader(CommonsLog.CommonsLog):
    
  def __init__(self,**modelVariables):
    super().__init__(__name__)
    self.url = modelVariables.get('DatasetUrl','DATASET IS NOT DEFNINED')
    self.useHeader = modelVariables.get('useHeader',0)
    self.debug(f'Loaded dataset -> {self.url}')
    pass
        
        
  def getData(self,*args,**kwargs):
    df = pd.read_csv(self.url, header=self.useHeader )
    self.debug(f'Loaded data from -> {self.url}')   
    return df