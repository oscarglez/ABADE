from sklearn.base import BaseEstimator, TransformerMixin

class Estimator(BaseEstimator, TransformerMixin):
    """
    This class contains the logic to score our data
    """
    def __init__(self):
        print('Custom estimator')
        
    def fit(self, x, y=None):
        return self

    def transform(self, df):
        """
        Estimation for category 1 (wages)
        """
        df['imp_202107'] = 4815
        df['dia_202107'] = 25
        return df