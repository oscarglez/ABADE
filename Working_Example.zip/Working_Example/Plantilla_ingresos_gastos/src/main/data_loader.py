import pandas as pd

# This should be a complete class taking the information from origin
def import_processed_data():
    """
    Function loading data, for the sake of simplicity it reads from a file
    """
    dataset = 'processed.csv'
    data = pd.read_csv('data/{0}'.format(dataset))
    return data