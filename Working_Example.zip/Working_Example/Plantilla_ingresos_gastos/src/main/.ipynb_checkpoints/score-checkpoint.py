import click
import logging
import joblib
import sklearn
from estimate import Estimator
import config_loader
from data_loader import import_processed_data

@click.command()
@click.option('--model_path', default="artifacts/pipeline.pkl", help='Model to be loaded')
def main(model_path:str):
    """
    Main function
    """
    # Model loading
    logging.debug("Loading model artifact...")
    model = joblib.load(model_path)
    
    # Data connection
    logging.debug("Retrieving data from sources...")
    data = import_processed_data()
    
    #Scoring
    logging.debug("Predict...")
    try:
        result = model.transform(data)
    except Exception:
        logging.error("Something went really wrong!")
    
    # Ending
    logging.info("Process ended")
    return result
    
if __name__== "__main__" :
    # Print Test messages before setting level
    logging.debug("Initialize the scoring function...")
    main()