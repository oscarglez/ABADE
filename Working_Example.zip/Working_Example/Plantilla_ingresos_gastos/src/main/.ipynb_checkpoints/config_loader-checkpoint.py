import logging
import yaml
from yaml.loader import SafeLoader

"""
Simple config loading functionality
"""

with open('src/config/params.yml') as f:
    params = yaml.load(f, Loader=SafeLoader)
    
# Open the file and load the file
with open('src/config/model_params.yml') as f:
    model_params = yaml.load(f, Loader=SafeLoader)
    
if params['debug']:
    logging.basicConfig(format='%(message)s',level=logging.DEBUG)
else:
    logging.basicConfig(format='%(message)s',level=logging.ERROR)