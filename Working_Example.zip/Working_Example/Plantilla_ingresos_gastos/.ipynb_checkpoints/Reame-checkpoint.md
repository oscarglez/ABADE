![](assets/img/logo.png)

## CBI: Ingresos y gastos

Este proyecto parte de la base de poder predecir los movimientos en saldo asociados a categorías concretas para usuarios de NOW.

### Repository structure

Este repositorio dispone de la siguiente structura

```
project-name
├── LICENSE.txt                                       <-
├── README.md                                         <-
├── artifacts/                                        <- Output artifacts
├── assets/                                           <- Assets (images, logos)
├── docs/                                             <- Project Documentation
└── src/                                              <- Source code
    ├── config/                                       <- Configuration files
    ├── main/                                         <- Main code
    |   └── score.py                                  <- Python code for scoring
    ├── notebooks/                                    <- Notebooks
    └── test/                                         <- Testing code
```

El resto de la documentación puede encontrarse bajo la carpeta *docs* o enlazada en [Confluence](http://url.de.confluente.es).