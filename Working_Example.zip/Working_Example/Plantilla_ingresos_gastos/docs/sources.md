![](../assets/img/logo.png)

## Fuentes

Las siguiente fuentes identifican el origen de datos necesario para poder llevar a cabo las transformaciones necesarias.

* ELE_TLE.SV_TLE_TX_MOVIMIENTOS_PH: El grueso de los movimientos a emplear como fuente de información
* ELE_TLE.TLE_DE_SUBCLOP: Origen de los datos de CLOP y SUBCLOP para poder realizar la categorización
* ELE_CLI.SV_CL_TM_CONTR_PERSONAS_PH: Fuente de la que se obtiene el campo *numperso*
* IKDEPMA1.DIG_USO_CANAL_NEW_6M_YYYYMM_O: Identificar al usuario como usuario de NOW
* IDTPGDP1.V_DTPGDP_CLIENTE_AUT: Verificar si existe consentimiento informado para el tratamiento de datos