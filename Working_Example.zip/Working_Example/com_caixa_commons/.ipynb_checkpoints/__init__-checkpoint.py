import logging
from logging.handlers import RotatingFileHandler
from com_caixa_commons.src.utils import Config


newConfig = Config.ConfigLoader()
loggerFileName = '../com_caixa_commons/log4python_config.txt'
print(__name__)
loggerConfig = newConfig.loadParameters (loggerFileName)

print('CREATE: CommonsLog')
print(loggerConfig['loggerName'])
print(loggerConfig['loggerFileName'])
print(loggerConfig['loggerFormatter'])
print(loggerConfig['loggerLevel'])
loggerName = loggerConfig['loggerName'] 
    
if loggerName == None: 
    name = loggerConfig['loggerName'] 
else:
    name = loggerName
print(name)
loggerFileName = loggerConfig['loggerFileName']
loggerFormatter = loggerConfig['loggerFormatter']
loggerLevel = loggerConfig['loggerLevel']
     
if loggerLevel == 'debug':
    enumLogLevel = logging.DEBUG
    numLogLevel = 4
elif loggerLevel == 'info':
    enumLogLevel = logging.INFO
    numLogLevel = 3
elif self.loggerLevel == 'warn':
    enumLogLevel =logging.WARN
    numLogLevel = 2
else:
    enumLogLevel = logging.ERROR
    numLogLevel = 1
    
logger = logging.getLogger()  # Gets the root logger
logger.setLevel(enumLogLevel )

fh = RotatingFileHandler(loggerFileName, maxBytes=2000000, backupCount=10)
formatter = logging.Formatter(loggerFormatter)
fh.setFormatter(formatter)
logger.addHandler(fh)

