import logging



class CommonsLog:            
    
  def __init__(self,usingName=None):
    if usingName == None:
        self.usingName = __name__
    else:
        self.usingName = usingName 
        
    self.logger = logging.getLogger(self.usingName)
    self.logger.info('Created logger for: ' + self.usingName)

  def debug (self,message): 
    if self.logger.isEnabledFor(logging.DEBUG):
        print(message)      
        self.logger.debug(message)
        
  def info (self,message):       
    if self.logger.isEnabledFor(logging.INFO):
        print(message)      
        self.logger.info(message)    
    
  def warn(self,message):  
    if self.logger.isEnabledFor(logging.WARN):
        print(message)      
        self.logger.warn(message)   
    
  def error(self,message):  
    if self.logger.isEnabledFor(logging.ERROR):
        print(message)      
        self.logger.error(message)    


