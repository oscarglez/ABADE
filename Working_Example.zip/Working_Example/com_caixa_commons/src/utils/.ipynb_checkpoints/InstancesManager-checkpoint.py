from com_caixa_commons.src.utils import CommonsLog
from importlib import import_module

class InstanceManager(CommonsLog.CommonsLog):    

    
 def __init__(self):    
    super().__init__(__name__)
    self.debug('CREATE INSTANCE MANAGER')

 def createInstance (self,instancePath,**kwargs):
    try:
        module_path, class_name = instancePath.rsplit('.', 1)        
        module = import_module(module_path)
        self.debug('INSTANCE OF MODULE {} WITH CLASS {} '.format (module_path,class_name))
        newInstance = getattr(module, class_name)
        self.debug(newInstance)
        return newInstance(**kwargs)
    except (ImportError, AttributeError) as e:
        raise ImportError(class_str)             