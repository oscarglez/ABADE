from com_caixa_commons.src.utils import CommonsLog
from com_caixa_commons.src.utils import InstancesManager
from com_caixa_commons.src.utils import ModelBase


class ModelDataLoader(ModelBase.ModelBase):    

    
 def __init__(self,**config):    
    super().__init__(**config)   
    self.debug('CREATE MODEL DATA LOADER')
    #This is the class which load data to create a model
    self.configDataLoaderClassName = config['DataLoaderClassName']
    #This is the method for load data for a model
    self.configDataLoaderMethod = config['DataLoaderMethodName']
    
    instanceManager = InstancesManager.InstanceManager()
    self.modelDataLoaderInstance = instanceManager.createInstance (self.configDataLoaderClassName,**config)


 def loadData (self,*args,**kwargs):
    try:    
        loadDataMethod = getattr( self.modelDataLoaderInstance,self.configDataLoaderMethod)(*args,**kwargs)
        self.debug(f'Data Loader result: {loadDataMethod}')
        return loadDataMethod
    except (ImportError, AttributeError) as e:
        raise ImportError(class_str)     