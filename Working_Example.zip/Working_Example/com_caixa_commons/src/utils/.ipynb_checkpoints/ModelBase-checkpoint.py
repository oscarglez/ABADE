from com_caixa_commons.src.utils import CommonsLog


class ModelBase(CommonsLog.CommonsLog):    

    
 def __init__(self,**kwargs):    
    super().__init__(__name__)
    self.debug('CREATE MODEL BASE')
    self.config = kwargs
