from com_caixa_commons.src.utils import CommonsLog
from com_caixa_commons.src.utils import InstancesManager
from com_caixa_commons.src.utils import ModelBase



#Model runner is an instance which load model predictor instance from file
#So first is init ModelRunner instance
#After load model, next step is start to predict. This start a new thread where predictions are executed
#When predictions ends then stop predict have been called

class ModelRunner(ModelBase.ModelBase):    

    
 def __init__(self,**config):    
    super().__init__(**config)   
    self.debug('CREATE MODEL RUNNER')
    #This is the class which run a model
    self.configRunnerClassName = config['RunnerClassName']
    #This is the method for run a model
    self.configRunnerMethod = config['RunnerMethodName']
    #This is the path where pickle is loaded
    self.runnerConfigPath = config['RunnerConfigPath']
    instanceManager = InstancesManager.InstanceManager()
    self.modelRunnerInstance = instanceManager.createInstance (self.configRunnerClassName,**{'configRunnerClassName': self.runnerConfigPath})


 def run (self,*args,**kwargs):
    try:    
        runningMethod = getattr( self.modelRunnerInstance,self.configRunnerMethod)(*args,**kwargs)
        self.debug(f'Running result: {runningMethod}')
        return runningMethod
    except (ImportError, AttributeError) as e:
        raise ImportError(class_str)     