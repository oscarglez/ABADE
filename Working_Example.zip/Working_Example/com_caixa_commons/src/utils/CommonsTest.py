from datetime import datetime
import time
from com_caixa_commons.src.utils import CommonsLog

class CommonsTest(CommonsLog.CommonsLog):

   def __init__(self):
     #CommonsLog.CommonsLog.__init__(self)
    super().__init__(__name__)
    
   def passMeABlock (self,block,*args):
    now = datetime.now()   
    if callable(block):
        blockResult = block(*args)
    else:
        raise Exception('Function is not callable')
        
    #time.sleep(3) # Sleep for 3 seconds
    difference=datetime.now()-now
    #CommonsLog.CommonsLog.debug(self,difference)
    self.debug(difference)
    return( difference,blockResult)

  
   def passMeABlockWithoutTime(self,block,*args):
    blockResult = self.passMeABlock(block, *args)
    return blockResult[1]

    
    