import threading
from com_caixa_commons.src.utils import CommonsLog

class CommonsThreading(CommonsLog.CommonsLog):

   def __init__(self):
     #CommonsLog.CommonsLog.__init__(self)
    super().__init__(__name__)
    wip_value = True
    
    
   def defineWIP (self,block,*args,**kwargs):
    #creates a thread with block function
    debug(f'Creating new thread for: {self.usingName}')
    if callable(block): 
        self.currentThread = threading.Thread(target=createWork, args=*args,kwargs=kwargs)
        debug(f'New thread created for: {self.usingName}')
    else:
        raise Exception(f"Function is not callable. So thread can't be created")
     
   def createWork(self,block,*args,**kwargs):
     while wip_value:
       blockResult = block(*args,**kwargs)    
    
   def startWork (self):
     debug(f'Starting thread')
     self.currentThread.start()
     debug(f'Thread running')
    
   def startWork (self):
    debug(f'Stoping thread')
    self.wip_value = True
    debug(f'Thread stoped')        