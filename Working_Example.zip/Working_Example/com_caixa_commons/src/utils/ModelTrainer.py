from com_caixa_commons.src.utils import CommonsLog
from com_caixa_commons.src.utils import InstancesManager
from com_caixa_commons.src.utils import ModelBase


class ModelTrainer(ModelBase.ModelBase):    

    
 def __init__(self,**config):    
    super().__init__(**config)   
    self.debug('CREATE MODEL TRAINER')
    #This is the class which train a model
    self.configTrainClassName = config['TrainClassName']
    #This is the method for train a model
    self.configTrainMethod = config['TrainMethodName']
    #This is the method for validate  a model
    self.configValidationMethod = config['ValidationMethod']   
    #This is the method for get model precission
    self.configPrecissionMethod = config['PrecissionMethod']     
    #This is the path where pickle is saved
    self.trainConfigPath = config['TrainConfigPath']
    instanceManager = InstancesManager.InstanceManager()
    configDict = {**{'configTrainClassName': self.trainConfigPath},**config}    
    self.modelTrainerInstance = instanceManager.createInstance (self.configTrainClassName,**configDict)


 def train (self,*args,**kwargs):
    try:    
        trainingMethod = getattr( self.modelTrainerInstance,self.configTrainMethod)(*args,**kwargs)
        return trainingMethod
    except (ImportError, AttributeError) as e:
        raise ImportError(class_str)       
        
 def isRunnnable (self,*args,**kwargs):
    try:    
        precissionMethod = getattr( self.modelTrainerInstance,self.configPrecissionMethod)(*args,**kwargs)
        self.debug(precissionMethod)
        self.debug(f'Precission result: {precissionMethod}')
        validationMethod = getattr( self.modelTrainerInstance,self.configValidationMethod)(precissionMethod,*args,**kwargs)
        self.debug(f'Validation result: {validationMethod}')
        return validationMethod , precissionMethod
    except (ImportError, AttributeError) as e:
        raise ImportError(class_str)         