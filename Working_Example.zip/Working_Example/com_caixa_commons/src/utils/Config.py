import pathlib

class ConfigLoader:    

  def __init__(self):
    print('CREATE: config -> ' + __name__)

  def readFileData (self,fileName): 
    file1 = open(fileName, 'r')
    self.Lines = file1.readlines()
    return self.Lines    
        
  def loadParameters (self,fileName):   
    fileContent = self.readFileData(fileName)    
    myVariable = {}
    for line in fileContent:
        variable = line.split(sep='=')
        myVariable[variable[0].strip()] = variable[1].strip()
    return myVariable

    
  def currentPath(self):  
    self.currentPath = pathlib.Path().resolve()  
    print(self.currentPath)
    return self.currentPath
  
    
